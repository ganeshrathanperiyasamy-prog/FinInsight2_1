<?php
include "database.php";

/* =====================================================
   KPI CALCULATIONS
===================================================== */

$total_revenue = 0;
$total_expense = 0;
$total_budget = 0;

$result = $conn->query("SELECT SUM(revenue) AS total FROM revenue");
if ($result) {
    $row = $result->fetch_assoc();
    $total_revenue = (float)($row['total'] ?? 0);
}

$result = $conn->query("SELECT SUM(actual_amount) AS total FROM gl_entries");
if ($result) {
    $row = $result->fetch_assoc();
    $total_expense = (float)($row['total'] ?? 0);
}

$result = $conn->query("SELECT SUM(budget) AS total FROM budgets");
if ($result) {
    $row = $result->fetch_assoc();
    $total_budget = (float)($row['total'] ?? 0);
}

$total_profit = $total_revenue - $total_expense;

$margin = ($total_revenue > 0)
    ? ($total_profit / $total_revenue) * 100
    : 0;

$variance = $total_expense - $total_budget;

$utilization = ($total_budget > 0)
    ? ($total_expense / $total_budget) * 100
    : 0;


/* =====================================================
   PRODUCT PROFITABILITY
===================================================== */

$products = [];

$product_sql = "
    SELECT product, SUM(revenue) AS revenue
    FROM revenue
    GROUP BY product
    ORDER BY revenue DESC
";

$product_result = $conn->query($product_sql);

if ($product_result) {

    while ($row = $product_result->fetch_assoc()) {

        $product_revenue = (float)$row['revenue'];

        if ($total_revenue > 0) {
            $allocated_cost =
                ($product_revenue / $total_revenue) * $total_expense;
        } else {
            $allocated_cost = 0;
        }

        $product_profit =
            $product_revenue - $allocated_cost;

        $product_margin =
            ($product_revenue > 0)
            ? ($product_profit / $product_revenue) * 100
            : 0;

        if ($product_margin >= 50) {
            $status = "HEALTHY MARGIN";
            $status_class = "good";
        } elseif ($product_margin >= 20) {
            $status = "MODERATE";
            $status_class = "medium";
        } else {
            $status = "LOW MARGIN";
            $status_class = "high";
        }

        $products[] = [
            "product" => $row['product'],
            "revenue" => $product_revenue,
            "cost" => $allocated_cost,
            "profit" => $product_profit,
            "margin" => $product_margin,
            "status" => $status,
            "status_class" => $status_class
        ];
    }
}


/* =====================================================
   BUDGET VS ACTUAL
===================================================== */

$variance_rows = [];

$variance_sql = "
    SELECT
        b.month,
        b.department,
        b.budget,
        COALESCE(SUM(g.actual_amount), 0) AS actual
    FROM budgets b
    LEFT JOIN gl_entries g
        ON b.department = g.department
        AND DATE_FORMAT(g.date, '%Y-%m') = b.month
    GROUP BY
        b.month,
        b.department,
        b.budget
    ORDER BY
        b.month,
        b.department
";

$variance_result = $conn->query($variance_sql);

if ($variance_result) {

    while ($row = $variance_result->fetch_assoc()) {

        $budget = (float)$row['budget'];
        $actual = (float)$row['actual'];

        $row['budget'] = $budget;
        $row['actual'] = $actual;

        $row['variance'] = $actual - $budget;

        $row['utilization'] =
            ($budget > 0)
            ? ($actual / $budget) * 100
            : 0;

        $variance_rows[] = $row;
    }
}


/* =====================================================
   CHART DATA
===================================================== */

$months = [];
$monthly_budget = [];
$monthly_actual = [];

foreach ($variance_rows as $row) {

    $month = $row['month'];

    if (!in_array($month, $months)) {
        $months[] = $month;
        $monthly_budget[] = 0;
        $monthly_actual[] = 0;
    }

    $index = array_search($month, $months);

    $monthly_budget[$index] += $row['budget'];
    $monthly_actual[$index] += $row['actual'];
}

$product_labels = [];
$product_revenue = [];

foreach ($products as $product) {
    $product_labels[] = $product['product'];
    $product_revenue[] = $product['revenue'];
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>FinInsight Dashboard</title>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>

/* =====================================================
   RESET
===================================================== */

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}


/* =====================================================
   BODY
===================================================== */

body {
    font-family: Arial, Helvetica, sans-serif;
    background: #f4f7fb;
    color: #1f2937;
}


/* =====================================================
   HEADER
===================================================== */

.header {
    background: #111827;
    color: white;
    padding: 25px 35px;
}

.header h1 {
    font-size: 30px;
}

.header p {
    margin-top: 7px;
    color: #cbd5e1;
    font-size: 14px;
}


/* =====================================================
   MAIN CONTAINER
===================================================== */

.container {
    width: 95%;
    max-width: 1400px;
    margin: 30px auto;
}


/* =====================================================
   KPI CARDS
===================================================== */

.kpi-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 20px;
    margin-bottom: 25px;
}

.card {
    background: white;
    padding: 22px;
    border-radius: 12px;

    box-shadow:
        0 3px 12px rgba(0,0,0,0.08);
}

.card h3 {
    font-size: 15px;
    color: #64748b;
    margin-bottom: 12px;
}

.value {
    font-size: 27px;
    font-weight: bold;
}

.revenue {
    color: #16a34a;
}

.expense {
    color: #dc2626;
}

.profit {
    color: #2563eb;
}

.margin {
    color: #7c3aed;
}


/* =====================================================
   SUMMARY
===================================================== */

.summary-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 20px;
}

.section {
    margin-bottom: 30px;
}

.section-title {
    font-size: 21px;
    margin-bottom: 15px;
}


/* =====================================================
   PROGRESS BAR
===================================================== */

.progress {
    height: 10px;
    background: #e5e7eb;
    border-radius: 10px;
    overflow: hidden;
    margin-top: 10px;
}

.progress-bar {
    height: 100%;
    background: #2563eb;
}


/* =====================================================
   TABLE
===================================================== */

.table-box {
    background: white;
    border-radius: 12px;
    overflow-x: auto;

    box-shadow:
        0 3px 12px rgba(0,0,0,0.08);
}

table {
    width: 100%;
    border-collapse: collapse;
}

th {
    background: #1e293b;
    color: white;
    padding: 14px;
    text-align: left;
}

td {
    padding: 14px;
    border-bottom: 1px solid #e5e7eb;
}

tr:hover {
    background: #f8fafc;
}


/* =====================================================
   STATUS BADGES
===================================================== */

.badge {
    display: inline-block;
    padding: 6px 11px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: bold;
}

.high {
    background: #fee2e2;
    color: #b91c1c;
}

.medium {
    background: #fef3c7;
    color: #92400e;
}

.good {
    background: #dcfce7;
    color: #166534;
}


/* =====================================================
   CHARTS
===================================================== */

.chart-card {
    min-height: 350px;
}

.chart-container {
    position: relative;
    height: 280px;
}


/* =====================================================
   FOOTER
===================================================== */

.footer {
    text-align: center;
    padding: 30px;
    color: #64748b;
}


/* =====================================================
   RESPONSIVE
===================================================== */

@media(max-width: 1000px) {

    .kpi-grid {
        grid-template-columns: repeat(2, 1fr);
    }
}

@media(max-width: 650px) {

    .kpi-grid,
    .summary-grid {
        grid-template-columns: 1fr;
    }

    .header {
        padding: 20px;
    }

    .container {
        width: 92%;
    }
}

</style>

</head>


<body>


<!-- =====================================================
     HEADER
===================================================== -->

<div class="header" style="display:flex; justify-content:space-between; align-items:center; gap:20px; flex-wrap:wrap;">

    <div>
        <h1>FinInsight</h1>

        <p>
            Expense Control & Profitability Analytics Dashboard
        </p>
    </div>

    <a href="upload.php" style="display:inline-block; background:#2563eb; color:#fff; text-decoration:none; padding:12px 18px; border-radius:8px; font-weight:700;">
        + Upload Financial Data
    </a>

</div>


<div class="container">


<!-- =====================================================
     KPI DASHBOARD
===================================================== -->

<div class="kpi-grid">


    <div class="card">

        <h3>Total Revenue</h3>

        <div class="value revenue">
            ₹<?= number_format($total_revenue) ?>
        </div>

    </div>


    <div class="card">

        <h3>Total Expense</h3>

        <div class="value expense">
            ₹<?= number_format($total_expense) ?>
        </div>

    </div>


    <div class="card">

        <h3>Total Profit</h3>

        <div class="value profit">
            ₹<?= number_format($total_profit) ?>
        </div>

    </div>


    <div class="card">

        <h3>Profit Margin</h3>

        <div class="value margin">
            <?= number_format($margin, 2) ?>%
        </div>

    </div>


</div>



<!-- =====================================================
     BUDGET SUMMARY
===================================================== -->

<div class="summary-grid section">


    <div class="card">

        <h3>Total Budget</h3>

        <div class="value">
            ₹<?= number_format($total_budget) ?>
        </div>

        <p style="margin-top:10px;">

            Budget Utilization:

            <strong>
                <?= number_format($utilization, 2) ?>%
            </strong>

        </p>


        <div class="progress">

            <div
                class="progress-bar"
                style="width: <?= min($utilization, 100) ?>%;">
            </div>

        </div>

    </div>



    <div class="card">

        <h3>Budget Variance</h3>

        <div
            class="value"
            style="color: <?= $variance > 0 ? '#dc2626' : '#16a34a' ?>;">

            ₹<?= number_format(abs($variance)) ?>

        </div>


        <p style="margin-top:10px;">

            <?php if ($variance > 0): ?>

                ⚠ Actual expense is above total budget.

            <?php else: ?>

                ✓ Actual expense is within total budget.

            <?php endif; ?>

        </p>

    </div>


</div>



<!-- =====================================================
     PRODUCT PROFITABILITY
===================================================== -->

<div class="section">

    <h2 class="section-title">
        Product Profitability
    </h2>


    <div class="table-box">

        <table>

            <thead>

                <tr>

                    <th>Product</th>

                    <th>Revenue</th>

                    <th>Allocated Cost</th>

                    <th>Profit</th>

                    <th>Margin</th>

                    <th>Status</th>

                </tr>

            </thead>


            <tbody>

            <?php if (count($products) > 0): ?>

                <?php foreach ($products as $p): ?>

                    <tr>

                        <td>
                            <strong>
                                <?= htmlspecialchars($p['product']) ?>
                            </strong>
                        </td>


                        <td>
                            ₹<?= number_format($p['revenue']) ?>
                        </td>


                        <td>
                            ₹<?= number_format($p['cost']) ?>
                        </td>


                        <td>
                            ₹<?= number_format($p['profit']) ?>
                        </td>


                        <td>
                            <?= number_format($p['margin'], 2) ?>%
                        </td>


                        <td>

                            <span class="badge <?= $p['status_class'] ?>">

                                <?= $p['status'] ?>

                            </span>

                        </td>

                    </tr>

                <?php endforeach; ?>

            <?php else: ?>

                <tr>

                    <td colspan="6">
                        No product data available.
                    </td>

                </tr>

            <?php endif; ?>

            </tbody>

        </table>

    </div>

</div>



<!-- =====================================================
     BUDGET VS ACTUAL
===================================================== -->

<div class="section">

    <h2 class="section-title">
        Budget vs Actual Expense
    </h2>


    <div class="table-box">

        <table>

            <thead>

                <tr>

                    <th>Month</th>

                    <th>Department</th>

                    <th>Budget</th>

                    <th>Actual</th>

                    <th>Variance</th>

                    <th>Utilization</th>

                    <th>Status</th>

                </tr>

            </thead>


            <tbody>

            <?php if (count($variance_rows) > 0): ?>

                <?php foreach ($variance_rows as $v): ?>

                    <?php

                    if ($v['utilization'] > 120) {

                        $status = "HIGH OVERRUN";
                        $class = "high";

                    } elseif ($v['utilization'] > 100) {

                        $status = "OVER BUDGET";
                        $class = "medium";

                    } else {

                        $status = "WITHIN BUDGET";
                        $class = "good";
                    }

                    ?>


                    <tr>

                        <td>
                            <?= htmlspecialchars($v['month']) ?>
                        </td>


                        <td>
                            <?= htmlspecialchars($v['department']) ?>
                        </td>


                        <td>
                            ₹<?= number_format($v['budget']) ?>
                        </td>


                        <td>
                            ₹<?= number_format($v['actual']) ?>
                        </td>


                        <td style="color:
                            <?= $v['variance'] > 0
                                ? '#dc2626'
                                : '#16a34a' ?>;">

                            ₹<?= number_format($v['variance']) ?>

                        </td>


                        <td>
                            <?= number_format(
                                $v['utilization'],
                                2
                            ) ?>%
                        </td>


                        <td>

                            <span class="badge <?= $class ?>">

                                <?= $status ?>

                            </span>

                        </td>

                    </tr>


                <?php endforeach; ?>

            <?php else: ?>

                <tr>

                    <td colspan="7">
                        No budget data available.
                    </td>

                </tr>

            <?php endif; ?>

            </tbody>

        </table>

    </div>

</div>



<!-- =====================================================
     FINANCIAL ANALYTICS CHARTS
===================================================== -->

<div class="section">

    <h2 class="section-title">
        Financial Analytics Charts
    </h2>


    <div class="summary-grid">


        <!-- MONTHLY CHART -->

        <div class="card chart-card">

            <h3>
                Monthly Budget vs Actual
            </h3>

            <div class="chart-container">

                <canvas id="budgetChart"></canvas>

            </div>

        </div>


        <!-- PRODUCT CHART -->

        <div class="card chart-card">

            <h3>
                Product Revenue
            </h3>

            <div class="chart-container">

                <canvas id="revenueChart"></canvas>

            </div>

        </div>


    </div>

</div>



</div>


<!-- =====================================================
     FOOTER
===================================================== -->

<div class="footer">

    FinInsight © 2026 | Finance Analytics Platform

</div>



<!-- =====================================================
     CHART JAVASCRIPT
===================================================== -->

<script>

const budgetLabels =
<?= json_encode($months) ?>;


const budgetValues =
<?= json_encode($monthly_budget) ?>;


const actualValues =
<?= json_encode($monthly_actual) ?>;


const productLabels =
<?= json_encode($product_labels) ?>;


const productRevenue =
<?= json_encode($product_revenue) ?>;



/* =====================================================
   BUDGET VS ACTUAL CHART
===================================================== */

new Chart(

    document.getElementById('budgetChart'),

    {

        type: 'bar',

        data: {

            labels: budgetLabels,

            datasets: [

                {
                    label: 'Budget',
                    data: budgetValues
                },

                {
                    label: 'Actual',
                    data: actualValues
                }

            ]

        },

        options: {

            responsive: true,

            maintainAspectRatio: false,

            plugins: {

                legend: {

                    position: 'bottom'

                }

            },

            scales: {

                y: {

                    beginAtZero: true

                }

            }

        }

    }

);



/* =====================================================
   PRODUCT REVENUE CHART
===================================================== */

new Chart(

    document.getElementById('revenueChart'),

    {

        type: 'doughnut',

        data: {

            labels: productLabels,

            datasets: [

                {

                    label: 'Revenue',

                    data: productRevenue

                }

            ]

        },

        options: {

            responsive: true,

            maintainAspectRatio: false,

            plugins: {

                legend: {

                    position: 'bottom'

                }

            }

        }

    }

);

</script>


</body>

</html>