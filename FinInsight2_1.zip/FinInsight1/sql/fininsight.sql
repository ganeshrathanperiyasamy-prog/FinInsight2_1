CREATE DATABASE IF NOT EXISTS fininsight;

USE fininsight;

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT IGNORE INTO users (username, password)
VALUES ('admin', 'admin123');

CREATE TABLE IF NOT EXISTS revenue (
    id INT AUTO_INCREMENT PRIMARY KEY,
    date DATE,
    product VARCHAR(100),
    revenue DECIMAL(15,2)
);

CREATE TABLE IF NOT EXISTS gl_entries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    date DATE,
    department VARCHAR(100),
    description VARCHAR(255),
    actual_amount DECIMAL(15,2)
);

CREATE TABLE IF NOT EXISTS budgets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    month VARCHAR(20),
    department VARCHAR(100),
    budget DECIMAL(15,2)
);