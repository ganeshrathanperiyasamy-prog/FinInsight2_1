<?php
include "database.php";

$message = "";
$error = "";
$uploaded_type = $_POST['data_type'] ?? 'revenue';

function clean_header($value) {
    return strtolower(trim((string)$value));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $uploaded_type = $_POST['data_type'] ?? '';

    if (!isset($_FILES['csv_file']) || $_FILES['csv_file']['error'] !== UPLOAD_ERR_OK) {
        $error = "Please choose a CSV file.";
    } else {
        $file = $_FILES['csv_file'];
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

        if ($ext !== 'csv') {
            $error = "Only CSV files are allowed.";
        } elseif ($file['size'] > 5 * 1024 * 1024) {
            $error = "File size must be 5 MB or less.";
        } else {
            $handle = fopen($file['tmp_name'], 'r');

            if (!$handle) {
                $error = "Unable to read the uploaded file.";
            } else {
                $header = fgetcsv($handle);
                $header = $header ? array_map('clean_header', $header) : [];
                $expected = [];

                if ($uploaded_type === 'revenue') {
                    $expected = ['date', 'product', 'revenue'];
                } elseif ($uploaded_type === 'gl') {
                    $expected = ['date', 'department', 'description', 'actual_amount'];
                } elseif ($uploaded_type === 'budget') {
                    $expected = ['month', 'department', 'budget'];
                } else {
                    $error = "Invalid data type selected.";
                }

                if (!$error && $header !== $expected) {
                    $error = "CSV columns do not match the selected data type. Expected: " . implode(', ', $expected);
                }

                $inserted = 0;
                $skipped = 0;

                if (!$error) {
                    $conn->begin_transaction();

                    try {
                        if ($uploaded_type === 'revenue') {
                            $stmt = $conn->prepare("INSERT INTO revenue (date, product, revenue) VALUES (?, ?, ?)");
                            if (!$stmt) throw new Exception($conn->error);

                            while (($row = fgetcsv($handle)) !== false) {
                                if (count($row) < 3 || trim(implode('', $row)) === '') { $skipped++; continue; }
                                $date = trim($row[0]);
                                $product = trim($row[1]);
                                $revenue = (float)$row[2];
                                if (!DateTime::createFromFormat('Y-m-d', $date) || $product === '' || !is_numeric($row[2])) { $skipped++; continue; }
                                $stmt->bind_param('ssd', $date, $product, $revenue);
                                if ($stmt->execute()) $inserted++; else $skipped++;
                            }
                            $stmt->close();
                        } elseif ($uploaded_type === 'gl') {
                            $stmt = $conn->prepare("INSERT INTO gl_entries (date, department, description, actual_amount) VALUES (?, ?, ?, ?)");
                            if (!$stmt) throw new Exception($conn->error);

                            while (($row = fgetcsv($handle)) !== false) {
                                if (count($row) < 4 || trim(implode('', $row)) === '') { $skipped++; continue; }
                                $date = trim($row[0]);
                                $department = trim($row[1]);
                                $description = trim($row[2]);
                                $amount = (float)$row[3];
                                if (!DateTime::createFromFormat('Y-m-d', $date) || $department === '' || $description === '' || !is_numeric($row[3])) { $skipped++; continue; }
                                $stmt->bind_param('sssd', $date, $department, $description, $amount);
                                if ($stmt->execute()) $inserted++; else $skipped++;
                            }
                            $stmt->close();
                        } else {
                            $stmt = $conn->prepare("INSERT INTO budgets (month, department, budget) VALUES (?, ?, ?)");
                            if (!$stmt) throw new Exception($conn->error);

                            while (($row = fgetcsv($handle)) !== false) {
                                if (count($row) < 3 || trim(implode('', $row)) === '') { $skipped++; continue; }
                                $month = trim($row[0]);
                                $department = trim($row[1]);
                                $budget = (float)$row[2];
                                if (!preg_match('/^\d{4}-\d{2}$/', $month) || $department === '' || !is_numeric($row[2])) { $skipped++; continue; }
                                $stmt->bind_param('ssd', $month, $department, $budget);
                                if ($stmt->execute()) $inserted++; else $skipped++;
                            }
                            $stmt->close();
                        }

                        $conn->commit();
                        $message = "Upload completed. $inserted record(s) added to the database.";
                        if ($skipped > 0) $message .= " $skipped row(s) were skipped because their data was invalid.";
                    } catch (Throwable $e) {
                        $conn->rollback();
                        $error = "Upload failed: " . $e->getMessage();
                    }
                }

                fclose($handle);
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>FinInsight - Upload Data</title>
<style>
body{font-family:Arial,Helvetica,sans-serif;background:#f4f7fb;color:#1f2937;margin:0}
.header{background:#111827;color:#fff;padding:24px 35px}
.container{width:92%;max-width:900px;margin:35px auto}
.card{background:#fff;border-radius:12px;padding:28px;box-shadow:0 4px 18px rgba(0,0,0,.08);margin-bottom:22px}
label{display:block;font-weight:700;margin:14px 0 8px}
select,input[type=file]{width:100%;padding:12px;border:1px solid #cbd5e1;border-radius:8px;background:#fff}
button,.back{display:inline-block;margin-top:20px;padding:12px 18px;border:0;border-radius:8px;background:#2563eb;color:#fff;font-weight:700;text-decoration:none;cursor:pointer}
.back{background:#64748b;margin-left:8px}
.success{background:#dcfce7;color:#166534;padding:12px;border-radius:8px;margin-bottom:18px}
.error{background:#fee2e2;color:#991b1b;padding:12px;border-radius:8px;margin-bottom:18px}
pre{background:#f8fafc;padding:15px;border-radius:8px;overflow:auto}
.small{color:#64748b}
</style>
</head>
<body>
<div class="header"><h1>FinInsight</h1><p>Upload Financial Data</p></div>
<div class="container">
<div class="card">
<h2>Upload CSV Data</h2>
<p class="small">Choose the data type, select your CSV file, and click Upload. New rows will be added to MySQL.</p>
<?php if ($message): ?><div class="success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
<?php if ($error): ?><div class="error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
<form method="POST" enctype="multipart/form-data">
<label for="data_type">Data Type</label>
<select name="data_type" id="data_type">
<option value="revenue" <?= $uploaded_type==='revenue'?'selected':'' ?>>Revenue</option>
<option value="gl" <?= $uploaded_type==='gl'?'selected':'' ?>>GL / Expense Entries</option>
<option value="budget" <?= $uploaded_type==='budget'?'selected':'' ?>>Budget</option>
</select>
<label for="csv_file">CSV File</label>
<input type="file" name="csv_file" id="csv_file" accept=".csv,text/csv" required>
<button type="submit">Upload Data</button>
<a class="back" href="dashboard.php">Back to Dashboard</a>
</form>
</div>
<div class="card">
<h3>CSV Formats</h3>
<p><strong>Revenue:</strong></p>
<pre>date,product,revenue
2026-10-01,Laptop,150000
2026-10-02,Mobile,90000</pre>
<p><strong>GL / Expense:</strong></p>
<pre>date,department,description,actual_amount
2026-10-01,Marketing,Campaign,50000
2026-10-02,Operations,Office,75000</pre>
<p><strong>Budget:</strong></p>
<pre>month,department,budget
2026-10,Marketing,60000
2026-10,Operations,80000</pre>
</div>
</div>
</body>
</html>
