<?php

/*
 * FinInsight - Automatic Database & Table Setup
 *
 * This file connects to MySQL without requiring the database to exist first.
 * It automatically creates the FinInsight database and required tables.
 */

$host = "localhost";
$username = "root";
$password = "";
$database = "fininsight";

/* Connect to MySQL server first (without selecting a database). */
$conn = new mysqli($host, $username, $password);

if ($conn->connect_error) {
    die("MySQL Connection Failed: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");

/* Create the database automatically if it does not exist. */
$create_db = "CREATE DATABASE IF NOT EXISTS `$database`
              CHARACTER SET utf8mb4
              COLLATE utf8mb4_unicode_ci";

if (!$conn->query($create_db)) {
    die("Database Creation Failed: " . $conn->error);
}

/* Select the newly created/existing database. */
if (!$conn->select_db($database)) {
    die("Database Selection Failed: " . $conn->error);
}

/* Create all required tables automatically. */
$tables = [

    "users" => "
        CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(100) NOT NULL UNIQUE,
            password VARCHAR(255) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ",

    "revenue" => "
        CREATE TABLE IF NOT EXISTS revenue (
            id INT AUTO_INCREMENT PRIMARY KEY,
            date DATE,
            product VARCHAR(100),
            revenue DECIMAL(15,2)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ",

    "gl_entries" => "
        CREATE TABLE IF NOT EXISTS gl_entries (
            id INT AUTO_INCREMENT PRIMARY KEY,
            date DATE,
            department VARCHAR(100),
            description VARCHAR(255),
            actual_amount DECIMAL(15,2)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ",

    "budgets" => "
        CREATE TABLE IF NOT EXISTS budgets (
            id INT AUTO_INCREMENT PRIMARY KEY,
            month VARCHAR(20),
            department VARCHAR(100),
            budget DECIMAL(15,2)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    "
];

foreach ($tables as $table => $sql) {
    if (!$conn->query($sql)) {
        die("Table '$table' Creation Failed: " . $conn->error);
    }
}

/* Create the default demo login if it does not already exist. */
$admin_username = "admin";
$admin_password = "admin123";

$stmt = $conn->prepare(
    "INSERT IGNORE INTO users (username, password) VALUES (?, ?)"
);

if ($stmt) {
    $stmt->bind_param("ss", $admin_username, $admin_password);
    $stmt->execute();
    $stmt->close();
}

?>
