import mysql.connector

print("=" * 55)
print("          FININSIGHT KPI CALCULATION")
print("=" * 55)

try:
    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="fininsight"
    )

    cursor = conn.cursor(dictionary=True)

    # Revenue
    cursor.execute("SELECT COALESCE(SUM(revenue),0) AS total FROM revenue")
    revenue = float(cursor.fetchone()["total"])

    # Expense
    cursor.execute("SELECT COALESCE(SUM(actual_amount),0) AS total FROM gl_entries")
    expense = float(cursor.fetchone()["total"])

    # Budget
    cursor.execute("SELECT COALESCE(SUM(budget),0) AS total FROM budgets")
    budget = float(cursor.fetchone()["total"])

    profit = revenue - expense

    margin = (profit / revenue * 100) if revenue > 0 else 0

    variance = expense - budget

    utilization = (expense / budget * 100) if budget > 0 else 0

    print("\nKPI RESULTS")
    print("-" * 55)
    print(f"Total Revenue       : ₹{revenue:,.2f}")
    print(f"Total Expense       : ₹{expense:,.2f}")
    print(f"Total Profit        : ₹{profit:,.2f}")
    print(f"Profit Margin       : {margin:.2f}%")
    print(f"Total Budget        : ₹{budget:,.2f}")
    print(f"Budget Variance     : ₹{variance:,.2f}")
    print(f"Budget Utilization  : {utilization:.2f}%")

    cursor.close()
    conn.close()

    print("\nKPI CALCULATION COMPLETED SUCCESSFULLY")

except Exception as e:
    print("\nERROR:", e)