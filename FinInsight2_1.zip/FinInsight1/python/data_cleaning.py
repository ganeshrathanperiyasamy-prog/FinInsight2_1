import pandas as pd
from pathlib import Path

print("=" * 50)
print("        FININSIGHT DATA CLEANING")
print("=" * 50)

# Project folders
BASE_DIR = Path(__file__).resolve().parent.parent
RAW_DIR = BASE_DIR / "data" / "raw"
PROCESSED_DIR = BASE_DIR / "data" / "processed"

# Create processed folder if it does not exist
PROCESSED_DIR.mkdir(parents=True, exist_ok=True)


# =====================================================
# 1. LOAD GL ENTRIES
# =====================================================

print("\n1. Loading GL Entries...")

gl_file = RAW_DIR / "gl_entries.csv"

gl = pd.read_csv(gl_file)

print("GL records:", len(gl))


# =====================================================
# 2. CLEAN GL DATA
# =====================================================

print("\n2. Cleaning GL data...")

gl["date"] = pd.to_datetime(gl["date"], errors="coerce")

gl["department"] = gl["department"].astype(str).str.strip()

gl["account"] = gl["account"].astype(str).str.strip()

gl["actual_amount"] = pd.to_numeric(
    gl["actual_amount"],
    errors="coerce"
)

# Remove missing values
gl = gl.dropna(
    subset=["date", "department", "account", "actual_amount"]
)

# Remove duplicates
gl = gl.drop_duplicates()

print("Clean GL records:", len(gl))


# =====================================================
# 3. LOAD BUDGET DATA
# =====================================================

print("\n3. Loading Budget data...")

budget_file = RAW_DIR / "budgets.csv"

budgets = pd.read_csv(budget_file)

print("Budget records:", len(budgets))


# =====================================================
# 4. CLEAN BUDGET DATA
# =====================================================

print("\n4. Cleaning Budget data...")

budgets["month"] = budgets["month"].astype(str).str.strip()

budgets["department"] = budgets["department"].astype(str).str.strip()

budgets["budget"] = pd.to_numeric(
    budgets["budget"],
    errors="coerce"
)

budgets = budgets.dropna(
    subset=["month", "department", "budget"]
)

budgets = budgets.drop_duplicates()

print("Clean Budget records:", len(budgets))


# =====================================================
# 5. LOAD REVENUE DATA
# =====================================================

print("\n5. Loading Revenue data...")

revenue_file = RAW_DIR / "revenue.csv"

revenue = pd.read_csv(revenue_file)

print("Revenue records:", len(revenue))


# =====================================================
# 6. CLEAN REVENUE DATA
# =====================================================

print("\n6. Cleaning Revenue data...")

revenue["date"] = pd.to_datetime(
    revenue["date"],
    errors="coerce"
)

revenue["product"] = revenue["product"].astype(str).str.strip()

revenue["channel"] = revenue["channel"].astype(str).str.strip()

revenue["revenue"] = pd.to_numeric(
    revenue["revenue"],
    errors="coerce"
)

revenue = revenue.dropna(
    subset=["date", "product", "channel", "revenue"]
)

revenue = revenue.drop_duplicates()

print("Clean Revenue records:", len(revenue))


# =====================================================
# 7. SAVE CLEANED FILES
# =====================================================

print("\n7. Saving cleaned files...")

gl.to_csv(
    PROCESSED_DIR / "cleaned_gl.csv",
    index=False
)

budgets.to_csv(
    PROCESSED_DIR / "cleaned_budgets.csv",
    index=False
)

revenue.to_csv(
    PROCESSED_DIR / "cleaned_revenue.csv",
    index=False
)


# =====================================================
# 8. SUMMARY
# =====================================================

print("\n" + "=" * 50)
print("DATA CLEANING COMPLETED SUCCESSFULLY")
print("=" * 50)

print("\nFiles created:")

print("✓ data/processed/cleaned_gl.csv")
print("✓ data/processed/cleaned_budgets.csv")
print("✓ data/processed/cleaned_revenue.csv")

print("\nGL records:", len(gl))
print("Budget records:", len(budgets))
print("Revenue records:", len(revenue))

print("\nNext step: KPI and Variance Analysis")