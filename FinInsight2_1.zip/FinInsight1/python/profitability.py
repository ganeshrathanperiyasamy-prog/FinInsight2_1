import pandas as pd
from pathlib import Path

print("=" * 55)
print("       FININSIGHT PROFITABILITY ANALYSIS")
print("=" * 55)

# Project paths
BASE_DIR = Path(__file__).resolve().parent.parent
PROCESSED_DIR = BASE_DIR / "data" / "processed"

# -----------------------------------------------------
# 1. LOAD CLEANED DATA
# -----------------------------------------------------

print("\n1. Loading cleaned data...")

revenue = pd.read_csv(
    PROCESSED_DIR / "cleaned_revenue.csv"
)

gl = pd.read_csv(
    PROCESSED_DIR / "cleaned_gl.csv"
)

print("Revenue records:", len(revenue))
print("Expense records:", len(gl))


# -----------------------------------------------------
# 2. PREPARE DATA
# -----------------------------------------------------

print("\n2. Preparing profitability data...")

# Total expenses by department
department_expenses = (
    gl.groupby("department")["actual_amount"]
    .sum()
    .reset_index()
)

department_expenses = department_expenses.rename(
    columns={
        "actual_amount": "department_expense"
    }
)


# -----------------------------------------------------
# 3. PRODUCT REVENUE
# -----------------------------------------------------

print("\n3. Calculating product revenue...")

product_revenue = (
    revenue.groupby("product")["revenue"]
    .sum()
    .reset_index()
)


# -----------------------------------------------------
# 4. ALLOCATE SHARED COST
# -----------------------------------------------------

print("\n4. Allocating costs...")

total_expense = gl["actual_amount"].sum()

total_revenue = revenue["revenue"].sum()

# Allocate total expense based on product revenue share
product_revenue["revenue_share"] = (
    product_revenue["revenue"] / total_revenue
)

product_revenue["allocated_cost"] = (
    product_revenue["revenue_share"]
    * total_expense
)


# -----------------------------------------------------
# 5. CALCULATE PROFIT
# -----------------------------------------------------

print("\n5. Calculating profit and margin...")

product_revenue["profit"] = (
    product_revenue["revenue"]
    - product_revenue["allocated_cost"]
)

product_revenue["margin_percent"] = (
    product_revenue["profit"]
    / product_revenue["revenue"]
    * 100
)


# -----------------------------------------------------
# 6. PRODUCT STATUS
# -----------------------------------------------------

def get_status(margin):

    if margin < 20:
        return "LOW MARGIN"

    elif margin < 40:
        return "MEDIUM MARGIN"

    else:
        return "HEALTHY MARGIN"


product_revenue["status"] = (
    product_revenue["margin_percent"]
    .apply(get_status)
)


# -----------------------------------------------------
# 7. ROUND VALUES
# -----------------------------------------------------

product_revenue["revenue"] = (
    product_revenue["revenue"].round(2)
)

product_revenue["revenue_share"] = (
    product_revenue["revenue_share"].round(4)
)

product_revenue["allocated_cost"] = (
    product_revenue["allocated_cost"].round(2)
)

product_revenue["profit"] = (
    product_revenue["profit"].round(2)
)

product_revenue["margin_percent"] = (
    product_revenue["margin_percent"].round(2)
)


# -----------------------------------------------------
# 8. SAVE PRODUCT PROFITABILITY
# -----------------------------------------------------

output_file = (
    PROCESSED_DIR / "profitability.csv"
)

product_revenue.to_csv(
    output_file,
    index=False
)


# -----------------------------------------------------
# 9. DISPLAY SUMMARY
# -----------------------------------------------------

print("\n" + "=" * 55)
print("PROFITABILITY ANALYSIS COMPLETED SUCCESSFULLY")
print("=" * 55)

print("\nOutput file:")
print("✓ data/processed/profitability.csv")

print("\nTotal Revenue:")
print(f"₹{total_revenue:,.2f}")

print("\nTotal Expense:")
print(f"₹{total_expense:,.2f}")

print("\nTotal Profit:")
print(
    f"₹{product_revenue['profit'].sum():,.2f}"
)

print("\nProduct Profitability:")
print()

for _, row in product_revenue.iterrows():

    print(
        f"{row['product']:<12} "
        f"Revenue: ₹{row['revenue']:,.0f} | "
        f"Profit: ₹{row['profit']:,.0f} | "
        f"Margin: {row['margin_percent']:.2f}% | "
        f"{row['status']}"
    )

print("\nNext step: PHP Dashboard")