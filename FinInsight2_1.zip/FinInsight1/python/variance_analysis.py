import pandas as pd
from pathlib import Path

print("=" * 55)
print("       FININSIGHT VARIANCE ANALYSIS")
print("=" * 55)

# Project paths
BASE_DIR = Path(__file__).resolve().parent.parent
PROCESSED_DIR = BASE_DIR / "data" / "processed"

# -----------------------------------------------------
# 1. LOAD CLEANED DATA
# -----------------------------------------------------

print("\n1. Loading cleaned data...")

gl = pd.read_csv(PROCESSED_DIR / "cleaned_gl.csv")
budgets = pd.read_csv(PROCESSED_DIR / "cleaned_budgets.csv")

print("GL records:", len(gl))
print("Budget records:", len(budgets))


# -----------------------------------------------------
# 2. PREPARE MONTH
# -----------------------------------------------------

print("\n2. Preparing monthly data...")

gl["date"] = pd.to_datetime(gl["date"])

gl["month"] = gl["date"].dt.strftime("%Y-%m")

print("Months found:", gl["month"].nunique())


# -----------------------------------------------------
# 3. CALCULATE ACTUAL EXPENSE
# -----------------------------------------------------

print("\n3. Calculating actual expenses...")

actual = (
    gl.groupby(["month", "department"], as_index=False)
      ["actual_amount"]
      .sum()
)

actual = actual.rename(
    columns={
        "actual_amount": "actual"
    }
)


# -----------------------------------------------------
# 4. MERGE BUDGET AND ACTUAL
# -----------------------------------------------------

print("\n4. Comparing budget vs actual...")

variance = pd.merge(
    budgets,
    actual,
    on=["month", "department"],
    how="outer"
)

variance["budget"] = variance["budget"].fillna(0)
variance["actual"] = variance["actual"].fillna(0)


# -----------------------------------------------------
# 5. CALCULATE VARIANCE
# -----------------------------------------------------

variance["variance"] = (
    variance["actual"] - variance["budget"]
)

variance["variance_percent"] = 0.0

mask = variance["budget"] != 0

variance.loc[mask, "variance_percent"] = (
    variance.loc[mask, "variance"]
    / variance.loc[mask, "budget"]
    * 100
)


# -----------------------------------------------------
# 6. BUDGET UTILIZATION
# -----------------------------------------------------

variance["budget_utilization"] = 0.0

variance.loc[mask, "budget_utilization"] = (
    variance.loc[mask, "actual"]
    / variance.loc[mask, "budget"]
    * 100
)


# -----------------------------------------------------
# 7. STATUS / ALERT
# -----------------------------------------------------

def get_status(row):

    if row["variance_percent"] > 10:
        return "HIGH OVERRUN"

    elif row["variance_percent"] > 0:
        return "OVER BUDGET"

    else:
        return "WITHIN BUDGET"


variance["status"] = variance.apply(
    get_status,
    axis=1
)


# -----------------------------------------------------
# 8. ROUND VALUES
# -----------------------------------------------------

variance["budget"] = variance["budget"].round(2)
variance["actual"] = variance["actual"].round(2)
variance["variance"] = variance["variance"].round(2)
variance["variance_percent"] = variance[
    "variance_percent"
].round(2)

variance["budget_utilization"] = variance[
    "budget_utilization"
].round(2)


# -----------------------------------------------------
# 9. SAVE RESULT
# -----------------------------------------------------

output_file = PROCESSED_DIR / "variance.csv"

variance.to_csv(
    output_file,
    index=False
)


# -----------------------------------------------------
# 10. DISPLAY SUMMARY
# -----------------------------------------------------

print("\n" + "=" * 55)
print("VARIANCE ANALYSIS COMPLETED SUCCESSFULLY")
print("=" * 55)

print("\nOutput file:")
print("✓ data/processed/variance.csv")

print("\nTotal Budget:")
print(f"₹{variance['budget'].sum():,.2f}")

print("\nTotal Actual:")
print(f"₹{variance['actual'].sum():,.2f}")

print("\nTotal Variance:")
print(f"₹{variance['variance'].sum():,.2f}")

print("\nAverage Budget Utilization:")
print(
    f"{variance['budget_utilization'].mean():.2f}%"
)

print("\nAlerts:")

high = (variance["status"] == "HIGH OVERRUN").sum()
over = (variance["status"] == "OVER BUDGET").sum()
within = (variance["status"] == "WITHIN BUDGET").sum()

print("HIGH OVERRUN :", high)
print("OVER BUDGET  :", over)
print("WITHIN BUDGET:", within)

print("\nNext step: Profitability Analysis")