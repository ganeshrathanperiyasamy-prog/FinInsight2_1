document.addEventListener("DOMContentLoaded", function () {

    console.log("FinInsight Dashboard Loaded Successfully");

    const cards = document.querySelectorAll(".card");

    cards.forEach(function (card) {
        card.addEventListener("mouseenter", function () {
            card.style.transition = "0.2s";
        });
    });

});