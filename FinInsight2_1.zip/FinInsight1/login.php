<?php
session_start();
include "database.php";

$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $username = trim($_POST["username"] ?? "");
    $password = $_POST["password"] ?? "";

    if ($username === "admin" && $password === "admin123") {

        $_SESSION["fininsight_user"] = "admin";

        header("Location: dashboard.php");
        exit;

    } else {

        $error = "Invalid username or password.";

    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>FinInsight Login</title>

<style>

* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

body {
    font-family: Arial, sans-serif;
    background: #f4f7fb;
    min-height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
}

.login-box {
    width: 380px;
    background: white;
    padding: 35px;
    border-radius: 15px;
    box-shadow: 0 5px 25px rgba(0,0,0,0.12);
}

h1 {
    text-align: center;
    color: #111827;
    margin-bottom: 8px;
}

.subtitle {
    text-align: center;
    color: #64748b;
    margin-bottom: 25px;
}

label {
    display: block;
    margin-bottom: 6px;
    font-weight: bold;
}

input {
    width: 100%;
    padding: 12px;
    border: 1px solid #cbd5e1;
    border-radius: 8px;
    margin-bottom: 18px;
}

button {
    width: 100%;
    padding: 12px;
    background: #2563eb;
    color: white;
    border: none;
    border-radius: 8px;
    font-size: 16px;
    cursor: pointer;
}

button:hover {
    background: #1d4ed8;
}

.error {
    background: #fee2e2;
    color: #b91c1c;
    padding: 10px;
    border-radius: 8px;
    margin-bottom: 15px;
    text-align: center;
}

.demo {
    margin-top: 20px;
    text-align: center;
    color: #64748b;
    font-size: 13px;
}

</style>

</head>

<body>

<div class="login-box">

<h1>FinInsight</h1>

<p class="subtitle">
Financial Analytics Platform
</p>

<?php if ($error): ?>

<div class="error">
<?= htmlspecialchars($error) ?>
</div>

<?php endif; ?>

<form method="POST">

<label>Username</label>

<input
    type="text"
    name="username"
    placeholder="Enter username"
    required
>

<label>Password</label>

<input
    type="password"
    name="password"
    placeholder="Enter password"
    required
>

<button type="submit">
Login
</button>

</form>

<div class="demo">
Username: <strong>admin</strong><br>
Password: <strong>admin123</strong>
</div>

</div>

</body>

</html>